package com.svv.optional1;

import java.util.Optional;

// using .map() method

public class OptionalDemo4 {
	
	public static void main(String[] args) {
		
		Person p = new Person("shibin",34,null);
//		Person p = new Person("shibin",34,null);

		Optional<String> countryOpt = Optional.ofNullable(p.getCountry());
		
		String country = countryOpt.map(String::toUpperCase).orElseGet(()->"no country found");
		
		System.out.println(country.toUpperCase());
		
	}
	
}	

