package com.svv.optional1;

import java.util.Optional;

// using .orElse() method

public class OptionalDemo2 {
	
	public static void main(String[] args) {
		
		Person p = new Person("shibin",34,"india");
//		Person p = new Person("shibin",34,"");

		Optional<String> countryOpt = Optional.ofNullable(p.getCountry());
		
		String country = countryOpt.orElse("no country name");
		
		System.out.println(country.toUpperCase());
		
	}
	
}	

