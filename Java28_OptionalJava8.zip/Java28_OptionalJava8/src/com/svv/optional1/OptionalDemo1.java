package com.svv.optional1;

import java.util.Optional;

// using .get() method

public class OptionalDemo1 {

	public static void main(String[] args) {

		Person p = new Person("shibin", 34, "india");
		// Person p = new Person("shibin",34,null);

		Optional<String> setCountry = Optional.ofNullable(p.getCountry());

		if (setCountry.isPresent()) {
			String cntry = setCountry.get();
			cntry = cntry.toUpperCase();
			p.setCountry(cntry);
			System.out.println(p);

		} else {
			System.out.println("Country not present");
		}

		// or Enabling functional programming

		Optional<Person> persoOpt = Optional.ofNullable(p);
		persoOpt.ifPresent(prsn -> {
			OptionalDemo1.printCountryUC(prsn);
		});

	}

	static void printCountryUC(Person p) {
		String country = p.getCountry().toUpperCase();
		p.setCountry(country);
		System.out.println(p);
	}

}
