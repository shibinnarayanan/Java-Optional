package com.svv;

import java.util.Optional;

public class OptionalDemo {

	public static void main(String[] args) {

		User user = new User("shibin", 34);

		Optional<User> optObject = Optional.ofNullable(user);

//		Optional<User> optObject = Optional.ofNullable(null);

//		------- method 1 ---------------
		if (optObject.isPresent()) {
			User user1 = optObject.get();
			System.out.println(user1);
		}
//		------- method 2 ---------------

		User user2 = optObject.orElse(new User("unknown", 0));
		System.out.println(user2);
//		------- method 3 ---------------

		User user3 = optObject.orElseGet(User::new);
		System.out.println(user3);

//		------- method 4 ---------------

		User user4 = optObject.orElseThrow(() -> new IllegalArgumentException("no user found"));
		System.out.println(user4);

//		------- method 5 ---------------

		Optional<String> nameOpt = Optional.ofNullable(user.getName());

		String name = nameOpt.map(String::toUpperCase).orElseGet(() -> "no name found");

		System.out.println(name);

	}

}
